package stringproblems;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Stack;

public class MaxDepth {
    public static int maxDepth(String s) {
        // Write your code here.
        int maxDepth = 0;

        return maxDepth;
    }

    public static String reverseString(String str)
    {
        //Write your code here
        String[] splitted = str.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i=splitted.length-1; i>=0; i--) {

            sb.append(splitted[i]).append(" ");
        }

        return sb.toString().trim();
    }

    public static String commonPrefix(String[] arr, int n) {

        String str1 =  Arrays.stream(arr).sorted().findFirst().get();
        String str2 =  Arrays.stream(arr).min(Comparator.reverseOrder()).get();

        if (str2.contains(str1))
            return str1;
        else if(str1.charAt(0) != str2.charAt(0))
            return "-1";
        else {
            StringBuilder sb = new StringBuilder();
            int i=0;
            for(char c: str1.toCharArray()) {
                if(c == str2.charAt(i++)) {
                    sb.append(String.valueOf(c));
                } else break;
            }
            return sb.toString();
        }

    }

    public static void main(String[] args) {

        System.out.println(reverseString("Welcome to Coding Ninjas"));

        String[] str = {"Codingninjas", "Coding", "Coders", "Codezen"};


        System.out.println(commonPrefix(str, str.length));

    }
}



