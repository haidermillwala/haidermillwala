import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");

        System.out.println(solution(10));

        System.out.println(firstNonRepeatingLetter("sTreSS"));

        String[] stringArray = {"Hello", "world", "Haider", "Millwala"};

        int longesrString = Arrays.stream(stringArray).map(String::length).sorted(Comparator.reverseOrder()).findFirst().get();

        System.out.println(longesrString);
    }
    public static int solution(int number) {

        return IntStream.range(1, number).filter(n -> n%3==0 || n%5==0).reduce(0, (el1, el2) -> el1 + el2);
    }

    public static String firstNonRepeatingLetter(String str) {

        int index = -1;
        int occ = 0;
        String lower = str.toLowerCase();
        for(char ch: lower.toCharArray()) {

            if(lower.indexOf(ch) == lower.lastIndexOf(ch)) {
                occ = lower.indexOf(ch);
                break;
            } else {
                index += 1;
            }
        }
        if(index == str.length() - 1) {
            return "";
        } else {
            return String.valueOf(str.charAt(occ));
        }
    }
}


