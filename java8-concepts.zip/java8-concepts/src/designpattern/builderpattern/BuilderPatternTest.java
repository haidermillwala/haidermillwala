package designpattern.builderpattern;

public class BuilderPatternTest {

    public static void main(String[] args) {
        Computer c1 =  new Computer.ComputerBuilder()
                .setHdd("512 GB")
                .setRam("16 GB")
                .setIsBluetoothEnabled(true)
                .setIsGraphicEnabled(true)
                .build();

        Computer c2 = new Computer.ComputerBuilder()
                .setHdd("1 TB")
                .build();

        System.out.println(c1);
        System.out.println(c2);
    }

}
