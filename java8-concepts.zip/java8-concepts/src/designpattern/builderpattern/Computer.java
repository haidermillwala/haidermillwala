package designpattern.builderpattern;

public class Computer {
    private String ram;
    private String hdd;
    private boolean isGraphicEnabled;
    private boolean isBluetoothEnabled;
    public String getHdd() {
        return hdd;
    }
    public String getRam() {
        return ram;
    }
    public boolean isGraphicEnabled() {
        return isGraphicEnabled;
    }
    public boolean isBluetoothEnabled() {
        return isBluetoothEnabled;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Computer{");
        sb.append("ram='").append(ram).append('\'');
        sb.append(", hdd='").append(hdd).append('\'');
        sb.append(", isGraphicEnabled=").append(isGraphicEnabled);
        sb.append(", isBluetoothEnabled=").append(isBluetoothEnabled);
        sb.append('}');
        return sb.toString();
    }

    private Computer(ComputerBuilder cb) {
        this.hdd = cb.hdd;
        this.ram = cb.ram;
        this.isBluetoothEnabled = cb.isBluetoothEnabled;
        this.isGraphicEnabled = cb.isGraphicEnabled;
    }
    public static class ComputerBuilder {
        private String ram;
        private String hdd;
        private boolean isGraphicEnabled;
        private boolean isBluetoothEnabled;

        public ComputerBuilder setHdd(String hdd) {
            this.hdd = hdd;
            return this;
        }
        public ComputerBuilder setRam(String ram) {
            this.ram = ram;
            return this;
        }
        public ComputerBuilder setIsGraphicEnabled(boolean isGraphicEnabled) {
            this.isGraphicEnabled = isGraphicEnabled;
            return this;
        }
        public ComputerBuilder setIsBluetoothEnabled(boolean isBluetoothEnabled) {
            this.isBluetoothEnabled = isBluetoothEnabled;
            return this;
        }
        public Computer build() {
            return new Computer(this);
        }
    }
}
