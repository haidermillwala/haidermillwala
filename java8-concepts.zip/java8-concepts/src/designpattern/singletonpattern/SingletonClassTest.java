package designpattern.singletonpattern;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SingletonClassTest  {

    static class TestClass1 extends Thread {

        @Override
        public void run() {
            MySingletonClass mySingletonClass1 = MySingletonClass.getInstance();
            System.out.println(mySingletonClass1.hashCode());
        }
    }

    static class TestClass2 extends Thread {

        @Override
        public void run() {
            MySingletonClass mySingletonClass2 = MySingletonClass.getInstance();
            System.out.println(mySingletonClass2.hashCode());
        }
    }

    public static void main(String[] args) {
        ExecutorService service = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        Thread t1 = new TestClass1();
        Thread t2 = new TestClass2();

        service.submit(t2);
        service.submit(t1);
        //t1.start();
        //t2.start();
    }
}
