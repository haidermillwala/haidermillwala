package designpattern.singletonpattern;

public class MySingletonClass implements Cloneable {

    private static MySingletonClass mySingletonClass = null;
    private MySingletonClass() {
        if(mySingletonClass != null) {
            throw new RuntimeException("Instance already exists");
        }
    }
    public static MySingletonClass getInstance() {
        if (mySingletonClass == null) {
            synchronized (MySingletonClass.class) {
                if(mySingletonClass == null)
                    mySingletonClass = new MySingletonClass();
            }
        }
        return mySingletonClass;
    }
    @Override
    public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton class. Clone not supported");
    }
 }
