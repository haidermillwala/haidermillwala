package designpattern.factorypattern;

public class NotificationFactory {

    public static Notifications createNotificationsFactory(String channel) {

        switch (channel) {
            case "SMS":
                return new SmsNotifications();
            case "EMAIL":
                return new EmailNotifications();
            case "PUSH":
                return new PushNotifcations();
            default:
                return null;
        }
    }
}
