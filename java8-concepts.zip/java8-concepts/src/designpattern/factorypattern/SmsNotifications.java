package designpattern.factorypattern;

public class SmsNotifications implements Notifications {


    @Override
    public void notifyUser() {
        System.out.println("Sending SMS Notifications");
    }
}
