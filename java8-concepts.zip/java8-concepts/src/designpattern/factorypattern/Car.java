package designpattern.factorypattern;

public class Car implements MotorVehicle{

    @Override
    public void build() {
        System.out.println("Building car");
    }
}
