package designpattern.factorypattern;

public abstract class MotorVehcileFactory {

    protected abstract MotorVehicle createMotorVehicle();
}
