package designpattern.factorypattern;

public class NotificationService {

    public static void main(String[] args) {

        //factory
        Notifications notifications = NotificationFactory.createNotificationsFactory("PUSH");
        notifications.notifyUser();

        //abstract factory
        AbstractNotificationsFactory notificationsFactory = new SmsNotificationsFactory();
        Notifications smsNotifications = notificationsFactory.createNotificationsFactory();
        smsNotifications.notifyUser();


    }
}
