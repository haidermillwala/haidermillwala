package designpattern.factorypattern;

public class MotorCycleFactory extends MotorVehcileFactory{
    @Override
    protected MotorVehicle createMotorVehicle() {
        return new MotorCycle();
    }
}
