package designpattern.factorypattern;

public interface Notifications {

    public void notifyUser();
}
