package designpattern.factorypattern;

public class EmailNotifications implements Notifications {

    @Override
    public void notifyUser() {
        System.out.println("Sending Email Notifications");
    }
}
