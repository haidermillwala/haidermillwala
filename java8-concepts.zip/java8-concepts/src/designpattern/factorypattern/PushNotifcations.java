package designpattern.factorypattern;

public class PushNotifcations implements Notifications {

    @Override
    public void notifyUser() {
        System.out.println("Sending Push Notifications");
    }
}
