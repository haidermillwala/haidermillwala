package designpattern.factorypattern;

public interface MotorVehicle {

    void build();
}
