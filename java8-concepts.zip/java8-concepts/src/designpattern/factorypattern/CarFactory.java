package designpattern.factorypattern;

public class CarFactory extends MotorVehcileFactory {

    @Override
    protected MotorVehicle createMotorVehicle() {
        return new Car();
    }
}
