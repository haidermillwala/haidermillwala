package designpattern.factorypattern;

public class SmsNotificationsFactory extends AbstractNotificationsFactory {

    @Override
    public Notifications createNotificationsFactory() {
        return new SmsNotifications();
    }
}

