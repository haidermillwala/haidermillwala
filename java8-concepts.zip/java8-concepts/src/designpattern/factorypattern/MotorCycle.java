package designpattern.factorypattern;

public class MotorCycle implements MotorVehicle{


    @Override
    public void build() {
        System.out.println("Building motorcyle");
    }
}
