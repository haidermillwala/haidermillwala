package designpattern.factorypattern;

public abstract class AbstractNotificationsFactory {
    public abstract Notifications createNotificationsFactory();

}
