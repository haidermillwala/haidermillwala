package designpattern.chainresponse;

public class Processor {

    private Processor nextProcessor;

    public Processor(Processor nextProcessor) {
        this.nextProcessor = nextProcessor;
    }

    public void process(Number request){
        if(nextProcessor!=null)
            nextProcessor.process(request);
    }
}


class NegativeProcessor extends Processor {

    public NegativeProcessor(Processor nextProcessor) {
        super(nextProcessor);
    }

    public void process(Number request) {

        if(request.getNumber() < 0)
            System.out.println("Negative Processor: " + request.getNumber());
        else
            super.process(request);
    }
}

class PositiveProcessor extends Processor {

    public PositiveProcessor(Processor nextProcessor) {
        super(nextProcessor);
    }

    public void process(Number request) {

        if(request.getNumber() > 0)
            System.out.println("Positive Processor: " + request.getNumber());
        else
            super.process(request);
    }
}

class ZeroProcessor extends Processor {

    public ZeroProcessor(Processor nextProcessor) {
        super(nextProcessor);
    }

    public void process(Number request) {

        if(request.getNumber() == 0)
            System.out.println("Zero Processor: " + request.getNumber());
        else super.process(request);
    }
}