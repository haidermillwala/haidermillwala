package designpattern.chainresponse;

public class Chain {

    static Processor chain;

    public Chain() {

        buildChain();
    }

    public void buildChain() {

        chain = new NegativeProcessor(new PositiveProcessor(new ZeroProcessor(null)));
    }

    public static void process(Number request) {
        chain.process(request);
    }

    public static void main(String[] args) {
        Chain chain = new Chain();

        chain.process(new Number(10));
        chain.process(new Number(-5));
        chain.process(new Number(0));
    }
}
