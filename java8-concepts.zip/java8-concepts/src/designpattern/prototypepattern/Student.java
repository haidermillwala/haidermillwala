package designpattern.prototypepattern;

public class Student {
    private String name;
    private String dob;
    private String age;
    public Student(String name, String dob, String age) {
        this.name = name;
        this.dob = dob;
        this.age = age;

    }
    public String getName() {
        return name;
    }

    public String getDob() {
        return dob;
    }

    public String getAge() {
        return age;
    }
}
