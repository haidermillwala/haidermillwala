package designpattern.prototypepattern;

import java.util.ArrayList;
import java.util.List;

public class Students implements Cloneable {
    private List<Student> studentList;

    public Students() {
        this.studentList = new ArrayList<>();
    }
    public Students(List<Student> studentList) {
        this.studentList = studentList;
    }
    @Override
    public Object clone() {
        return new Students(this.studentList); // shallow copy
    }
}
