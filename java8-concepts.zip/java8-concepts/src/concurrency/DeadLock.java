package concurrency;

public class DeadLock {

    private static final String resource1 = "Printer";
    private static final String resource2 = "Scanner";

    public static void main(String[] args) {

        Desktop desktop = new Desktop();
        desktop.start();

        Laptop laptop = new Laptop();
        laptop.start();
    }

    private static class Desktop extends Thread {

        @Override
        public void run() {

            synchronized (resource1) {
                System.out.println("Desktop has locked " + resource1);
                try{
                    Thread.sleep(1000);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            System.out.println("Desktop is waiting for " + resource2);
            synchronized (resource2) {
                System.out.println("Desktop has locked " + resource1);
            }
        }
    }

    private static class Laptop extends Thread {

        @Override
        public void run() {
            synchronized (resource2) {
                System.out.println("Laptop has locked " + resource2);
                try{
                    Thread.sleep(100);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            System.out.println("Laptop is waiting for " + resource1);
            synchronized (resource1) {
                System.out.println("Laptop has locked " + resource2);
            }
        }
    }
}
