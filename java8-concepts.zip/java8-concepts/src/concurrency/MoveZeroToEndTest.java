package concurrency;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MoveZeroToEndTest {

    @Test
    public void test1() {
        String[] A = {"Haider", "Millwala"};
        String[] B = {"Haider", "Millwala"};
        assertArrayEquals(A, B, "message");
    }

}