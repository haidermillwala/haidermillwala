package concurrency;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Solution {
    public static List<Integer> sortedArray(int[] a, int[] b) {
        // Write your code here
        int i = 0, j = 0;

        int n = a.length, m = b.length;

        ArrayList<Integer> result = new ArrayList<>();

        while (i < n && j < m) {

            if (a[i] < b[j]) {

                if (result.size() == 0 || result.get(result.size() - 1) != a[i])
                    result.add(a[i]);
                i++;
            } else {

                if (result.size() == 0 || result.get(result.size() - 1) != b[j])
                    result.add(b[j]);
                j++;
            }
        }

        while (i < n) {

            if (result.get(result.size() - 1) != a[i])
                result.add(a[i]);
        }

        while (j < m) {

            if (result.get(result.size() - 1) != b[j])
                result.add(b[i]);
        }

        return result;
    }

    public static int traffic(int n, int m, int []vehicle) {
        // Write your code here.
        int flippedCounter = 0;
        int max = 0, counter=0;
        int loopCounter =0;

        for (int i=0; i<n; i++) {

            if(vehicle[i] == 1)
                counter++;
            else if(vehicle[i] == 0 && flippedCounter < m) {
                counter++;
                flippedCounter++;
            }
            else {
                counter = 0;
                flippedCounter = 0;
                loopCounter++;
                i = loopCounter;
            }


            max = Math.max(max, counter);
        }

        return max;
    }
    /*
        Tine Complexity: O(n * n)
     */
    public static int longestSubarrayWithSumK(int []a, long k) {
        // Write your code here
        int n = a.length;


        int result = 0;
        for(int i=0; i<n; i++) {
            int sum = 0;
            for(int j=i; j<n; j++) {

                sum += a[j];
                if(sum == k)
                    result = Math.max(result, j - i + 1);
            }

        }
        return result;

    }
    /*
        Works for positive and negative numbers
        Time Complexity: O(n * logn) :: n for looping through the loop. logn for map(ordered map) insert and search operation
                        can be O(n) if we use unordered map. but in worst case the complexity will be O(n * n) if there are lot of collisions.
        Space Complexity : 0(n)
     */
    public static int longestSubarrayWithSumK_better(int[] a, long k){

        HashMap<Long, Integer> prefix = new HashMap<>();

        int length = 0;

        long sum = 0;

        for (int i=0; i<a.length; i++) {

            sum += a[i];
            if (prefix.containsKey(sum - k)) {
                length = Math.max(length, i - prefix.get(sum - k));
            }
            if(!prefix.containsKey(sum))
            {
                prefix.put(sum, i);
            }
        }
        return length;
    }

    /*
        Works for only positive integers.
        Time Complexity: O(2 * n) in worst case scenario.
        Space complexity: O(1)
    */
    public static int longestSubarrayWithSumK_optimal(int[] a, long k) {

       int left = 0, right = 0;
       int maxLength = 0;
       long sum = a[0];

       while(right < a.length) {
            while (left <= right && sum > k) {
                sum -= a[left];
                left++;
            }
            if(sum == k)
                maxLength = Math.max(maxLength, right - left + 1);

           right++;
           if(right < a.length)
               sum += a[right];
       }
       return maxLength;
    }
    public static void sort012(int[] arr)
    {
        //Write your code here

        int low = 0, mid = 0, high = arr.length - 1;

        while (mid <= high) {

            if(arr[mid] == 0) {

                int temp = arr[low];
                arr[low] = arr[mid];
                arr[mid] = temp;
                low++;
                mid++;
            } else if(arr[mid] == 1) {
                mid++;
            } else if(arr[mid] == 2) {
                int temp = arr[mid];
                arr[mid] = arr[high];
                arr[high] = temp;
                high--;
            }
        }

        for(int i=0; i<arr.length; i++) {
            System.out.print(arr[i]);
        }
    }

    public static int majorityElement(int []v) {
        // Write your code here
        HashMap<Integer, Integer> map = new HashMap<>();

        for (int i=0; i<v.length; i++) {

            map.put(v[i], map.getOrDefault(v[i], 0) + 1);
        }

        for(Map.Entry<Integer, Integer> m: map.entrySet()) {

            if(m.getValue() > v.length/2)
                return m.getKey();
        }
        return 0;
    }

    public static long maxSubarraySum(int[] arr, int n) {
        // write your code here
        long maxSum = Long.MIN_VALUE, sum = 0;
        for (int i=0; i<n; i++) {
            sum += arr[i];
            if(sum > maxSum)
                maxSum = sum;

            if(sum < 0)
                sum = 0;

            if(maxSum < 0)
                maxSum = 0;
        }

        return maxSum;
    }

    public int transformAndAdd(List<Long> l,
                               Function<Long, Long> ops) {
        int result = 0;
        for (Long s : l)
            result += ops.apply(s);
        return result;
    }
    public static Long doHalf(Long x) {
        return x / 2;
    }




    public static void main(String[] args) {

        //int[] arr = {1,1,1,1,0,0,0,1,1,1,0,0,0,1,0,1,1,1,0,0,1,0,0,0,0,0,0,1,0,0,0,1,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,1,0,1,1,1,0,1,0,1,0,1,1,0,0,0,0,1,1,1,1,1,0,1,1,0,0,0,0,1,0,1,1,1,0,0,1,0,1,0,1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,1,1,0,0,0,0,1,0,0,1,0,1,1,0,0,0,1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,0,0,1,1,1,0,1,0,0,1,0,0,0,1,1,0,0,1,1,1,0,1,1,1,0,1,0,0,1,0,0,0,0,0,1,1,1,0,0,0,1,1,1,0,1,0,0,0,1,1,1,1,0,0,1,0,0,0,0,1,0,1,1,0,0,1,1,1,0,0,0,0,1,1,1,1,1,1,1,0,1,1,0,0,0,1,1,1,1,0,1,0,1,0,1,0,1,0,1,1,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,1,1,1,0,0,1,1,1,1,0,0,1,0,1,0,0,1,0,1,0,1,1,0,1,1,0,1,1,0,0,0,0,0,1,1,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,0,0,0,1,0,1,0,1,1,1,1,1,0,0,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,1,1,0,0,0,1,0,1,0,0,0,1,1,0,1,0,0,0,1,0,0,0,1,1,0,0,1,0,0,0,0,1,1,1,0,0,1,1,1,0,0,0,1,0,0,1,1,1,0,1,1,0,0,1,1,0,0,1,1,0,0,0,0,1,0,1,1,0,0,0,0,0,1,1,1,0,0,1,0,1,0,0,0,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,1,0,0,1,1,0,1,0,0,0,0,0,1,1,1,1,1,1,0,1,0,1,1,1,1,0,1,0,0,1,1,0,1,1,1,1,1,1,0,1,0,1,1,1,1,0,0,0,0,0,1,0,1,0,1,0,1,1,0,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,1,1,0,1,0,0,0,0,1,1,0,0,0,0,0,1,1,0,0,1,1,0,1,1,0,0,1,0,0,0,1,0,1,0,0,0,1,1,0,0,1,1,0,1,0,0,0,0,1,1,1,0,0,0,0,1};

        //int[] arr = {0,1,0,0,1,0,1,1};
        //System.out.println(arr.length);
        //System.out.println(traffic(arr.length, 179, arr));

        //int[] arr2 = {1,0,0,3};

        //System.out.println(longestSubarrayWithSumK_optimal(arr2, 3));

        //int[] arr1 = {0, 2, 1, 2, 0, 1};

        //sort012(arr1);

        int[] arr = {18, -6, -6, -5, 7, 10, 16, -6, -2, 0};


        int[] arr1 = {-7, -8, -16, -4, -8, -5, -7, -11, -10, -12, -4, -6, -4, -16, -10};
        int n = 15;
        //System.out.println(maxSubarraySum(arr1, arr1.length));

        List<Long> sqaures = Arrays.stream(arr1).mapToObj(a-> Long.valueOf(a*a)).collect(Collectors.toList());

        sqaures.stream().forEach(System.out::println);

        Solution solution = new Solution();

        int halves = solution.transformAndAdd(sqaures, Solution::doHalf);

        System.out.println("Half " + halves);
    }
}
