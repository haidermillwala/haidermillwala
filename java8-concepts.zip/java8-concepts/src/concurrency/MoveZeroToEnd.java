package concurrency;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MoveZeroToEnd {

    public static int[] moveZeros(int n, int []a) {
        // Write your code here.
        int[] result = new int[n];

        int counter = 0, zeroCounter=0;
        for (int i=0; i<n; i++) {

            if (a[i]!=0) {
                result[counter] = a[i];
                counter++;
            } else zeroCounter++;
        }

        for(int i=zeroCounter+1; i<counter - n; i++) {
            result[i] = 0;
        }

        return result;
    }

    public static void main(String[] args) {

        int[] input = {4,0,3,2,5};

        int[] result = moveZeros(input.length, input);

        List ints = Arrays.asList(1,2);
        List list = ints;
        //list.add(3.14);

        Optional got = Optional.of("GOT");

        String[] str = new String[10];

        Optional str9 = Optional.ofNullable(str[9]);


        System.out.println(got.isPresent());
        System.out.println(str9.isPresent());
        for(int i=0; i<input.length; i++) {

            System.out.print(result[i] + " ");
        }
    }
}
