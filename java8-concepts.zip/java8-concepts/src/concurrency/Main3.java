package concurrency;

import java.util.* ;
import java.io.*;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;


public class Main3 {
    //Brute force
    public static List< Integer > superiorElements(int []a) {
        // Write your code here.

        List<Integer> result = new ArrayList<>();
        for (int i=0; i<a.length; i++) {

            int leader = a[i];
            boolean isLeader = true;
            for(int j=i+1; j<a.length; j++) {

                if(leader<=a[j]){
                    isLeader = false;
                    break;
                }
            }

            if(isLeader)
                result.add(leader);
        }
        Collections.sort(result);
        return result;
    }

    //optimal
    public static List<Integer> superiorElements_Optimal(int[] a) {

        List<Integer> result = new ArrayList<>();

        int leader = a[a.length - 1];
        result.add(leader);
        for(int i = a.length-2; i>=0; i--) {

            if(a[i] > leader) {
                result.add(a[i]);
                leader = a[i];
            }
            Math.abs(leader);
        }
        return result;
    }

    public static int longestSuccessiveElements(int []a) {
        // Write your code here.

        Arrays.sort(a);

        int sequence = 1;
        int maxSequence = Integer.MIN_VALUE;
        for(int i=0; i<a.length - 1; i++) {
            if(a[i] == a[i+1])
                continue;
            if(Math.abs(a[i] - a[i+1]) == 1) {
                sequence++;
            } else {
                maxSequence = Math.max(sequence, maxSequence);
                sequence = 1;
            }
        }

        return Math.max(sequence, maxSequence);
    }

    public static List< List < Integer > > triplet(int n, int []arr) {
        // Write your code here.
        List<List<Integer>> result = new ArrayList<>();
        Set<List<Integer>> ds = new HashSet<>();

        for (int i = 0; i < arr.length; i++) {

            for (int j = i + 1; j < arr.length; j++) {

                for (int k = j + 1; k < arr.length; k++) {

                    if (arr[i] + arr[j] + arr[k] == 0) {

                        List<Integer> temp = new ArrayList<>();
                        temp.add(arr[i]);
                        temp.add(arr[j]);
                        temp.add(arr[k]);

                        List<Integer> sortedTemp = temp;
                        Collections.sort(sortedTemp);

                        if(!ds.contains(sortedTemp)) {
                            result.add(temp);
                            ds.add(sortedTemp);
                        }
                    }
                }
            }
        }
        return result;
    }


    public static void main(String[] args) {

        int[] arr = {-18, -1, -44, -48, -9, -16, -36, -13, 29, 17, -12, 9, -49 };


        Arrays.sort(arr);

        Arrays.stream(arr).forEach(a -> System.out.print(a + " "));

        System.out.println();

        System.out.println(triplet(arr.length, arr));
    }
}