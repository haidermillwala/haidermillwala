package concurrency;

import java.util.* ;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.io.*;
public class ZeroMatrix {
    public static ArrayList<ArrayList<Integer>> zeroMatrix(ArrayList<ArrayList<Integer>> matrix, Integer n, Integer m) {
        // Write your code here.
        for(int i=0; i<n; i++) {

            for (int j=0; j<m; j++) {

                if (matrix.get(i).get(j) == 0) {
                    markRow(matrix,i, m);
                    markColumn(matrix, j, n);
                }
            }
        }

        List<List<Integer>> newMatrix= matrix.stream()
                .map(row -> row.stream()
                        .map(element -> element==-1 ? 0 : element)
                        .collect(Collectors.toList())).collect(Collectors.toList());

        return (ArrayList) newMatrix;
    }

    public static  void markRow(ArrayList<ArrayList<Integer>> matrix, Integer rowToMark, Integer column) {

        for(int i=0; i<column; i++ ) {

            if(matrix.get(rowToMark).get(i) !=0)
                matrix.get(rowToMark).set(i, -1);
        }
    }

    public static void markColumn(ArrayList<ArrayList<Integer>> matrix, Integer columnToMark, Integer row) {

        for(int i=0; i<row; i++) {

            if(matrix.get(i).get(columnToMark)!=0)
                matrix.get(i).set(columnToMark, -1);

        }
    }

    public static void main(String[] args) {

        ArrayList<ArrayList<Integer>> matrix = new ArrayList<>();

        ArrayList<Integer> list1 = new ArrayList<>(Arrays.asList(2, 4, 3));
        ArrayList<Integer> list2 = new ArrayList<>(Arrays.asList(1,0,0));

        matrix.add(list1);
        matrix.add(list2);

        System.out.println(zeroMatrix(matrix, matrix.size(), list1.size()));
    }
}