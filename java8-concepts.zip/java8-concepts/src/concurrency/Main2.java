package concurrency;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main2 {
    public static  boolean validParenthesis(String s) {

        Stack<Character> ds = new Stack<>();

        for(Character c: s.toCharArray()) {
            if(c == '(' || c == '[' || c== '{') {
                ds.push(c);
                continue;
            }

            if(ds.empty())
                return false;

            switch(c) {
                case ')':
                    Character ch1 = ds.pop();
                    if(ch1 == '{' || ch1 == '[')
                        return false;
                    break;
                case ']':
                    Character ch2 = ds.pop();
                    if(ch2 == '(' || ch2 == '{')
                        return false;
                    break;
                case '}':
                    Character ch3 = ds.pop();
                    if(ch3 == '(' || ch3 == '[')
                        return false;
                    break;
            }

        }


        return ds.empty();

    }
    public static void main(String[] args) {

        List<List<Integer>> lists = new ArrayList<>();

        String[] strings = {"amazon", "amazed", "am", "amaze", "amazing", "amazes"};

        List<Integer> flatMap = lists.stream().flatMap(integers -> integers.stream()).collect(Collectors.toList());

        String s1 = strings[0];


        ArrayList<String> stringList = new ArrayList<>();
        stringList.add("Haider");
        stringList.add("Millwala");
        stringList.add("Haider");
        stringList.add("Millwala");
        ConcurrentHashMap<String, Long> map = stringList.stream().
                collect(Collectors
                        .groupingBy(Function.identity(),
                                ConcurrentHashMap<String, Long>::new,
                                Collectors.counting()));
       for(Map.Entry<String, Long> entry: map.entrySet()) {
           System.out.println("Key is " + entry.getKey() + " value is " + entry.getValue());
       }
    }
}
