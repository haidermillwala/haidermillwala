package concurrency;

import java.util.*;
public class RemoveDuplicate {

    public static int removeDuplicates(ArrayList<Integer> arr,int n) {
        // Write your code here.

        return Long.valueOf(arr.stream().distinct().count()).intValue();
    }
}
