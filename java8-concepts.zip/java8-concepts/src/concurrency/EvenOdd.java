package concurrency;

import java.util.concurrent.CompletableFuture;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

public class EvenOdd {

    private static Object object = new Object();

    private IntPredicate oddPredicate = i -> i%2!=0;

    private IntPredicate evenPredicate = i -> i%2==0;


    public static void main(String[] args) {
        //CompletableFuture<Integer> oddCompletableFuture = CompletableFuture.as
        IntStream.rangeClosed(1, 10)
                .forEach(System.out::println);
    }

    public static void print(int i) {

        synchronized (object){
            try{
                System.out.println(Thread.currentThread().getName() + " Value" + i);
                object.notify();
            } catch(Exception e) {
                e.printStackTrace();
            }

        }
    }
}
