package concurrency;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Solution2 {

    public static void main(String[] args) {
        int[] arr1 = {0, 2, 4, 6, 8, 9, 10};
        int[] arr2 = {1, 2, 6, 7, 11, 12, 13};


        int[] arr3 = {2, 1, 10, 4, 8, 11};
        int k=3;

        Object[] answer = Arrays.stream(arr3).boxed().sorted(Comparator.reverseOrder()).toArray();

        System.out.println(answer);

        int arr1Length = arr1.length;
        int arr2Lnegth = arr2.length;

        int[] merged = new int[arr1Length + arr2Lnegth];

        int arr1Position = 0, arr2Position = 0, mergePosition = 0;

        while (arr1Position < arr1Length && arr2Position < arr2Lnegth) {

            if(arr1[arr1Position] < arr2[arr2Position]) {

                merged[mergePosition++] = arr1[arr1Position++];
            } else {
                merged[mergePosition++] = arr2[arr2Position++];
            }
        }

        while (arr1Position < arr1Length) {
            merged[mergePosition++] = arr1[arr1Position++];
        }

        while (arr2Position < arr2Lnegth) {
            merged[mergePosition++] = arr2[arr2Position++];
        }

        Arrays.stream(merged).forEach(System.out::println);



        //List.of(1L, 4L, 1L).sort(Comparator.reverseOrder());

        String string = "aadc";

        int[] count = new int[256];

        for(int i=0; i<string.length(); i++) {

            count[string.charAt(i)]++;

        }



        for(int j=0; j<string.length(); j++) {

            if(count[string.charAt(j)] == 1){
                System.out.println(string.charAt(j));
                break;
            }

        }
    }
}

