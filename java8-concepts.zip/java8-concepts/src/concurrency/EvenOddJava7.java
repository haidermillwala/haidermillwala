package concurrency;

public class EvenOddJava7 implements Runnable {

    Object object;

    EvenOddJava7(Object object) {
        this.object = object;
    }

    static int count = 1;
    @Override
    public void run() {

        while(count <= 10) {

            if(count%2!=0 && Thread.currentThread().getName().equals("odd")) {
                synchronized (object) {
                    System.out.println(Thread.currentThread().getName() + " " + count);
                    count++;
                    try {
                        object.wait();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            if(count%2==0 && Thread.currentThread().getName().equals("even")) {
                synchronized (object) {
                    System.out.println(Thread.currentThread().getName() + " " + count);
                    count++;
                    object.notify();
                }
            }

        }
    }

    public static void main(String[] args) {
        Object lock = new Object();
        Runnable r1 = new EvenOddJava7(lock);
        Runnable r2 = new EvenOddJava7(lock);

        new Thread(r1, "odd").start();
        new Thread(r2, "even").start();
    }
}
