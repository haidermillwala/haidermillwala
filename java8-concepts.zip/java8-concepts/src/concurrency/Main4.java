package concurrency;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Main4 {

    static Main4 main4;
    private Main4() {

    }
    public Main4 getInstance() {
        if(main4 == null) {
            main4 = new Main4();
        }
        return main4;
    }
    public static void main(String[] args) {

        List<Integer> list1 = Arrays.asList(2,4,6,7,2,11);


        List<Integer> list2 = list1.stream().sorted().collect(Collectors.toList());

        System.out.println(list2);
    }
}
