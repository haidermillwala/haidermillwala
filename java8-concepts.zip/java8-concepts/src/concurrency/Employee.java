package concurrency;

import java.util.*;
 abstract class Person {
    Person () {
        System.out.println("Person Constructor");
    }
}

public class Employee extends Person {

    private int id;
    private String name;

    private Long salary;

    Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }
     public void setId(int id) {
         this.id = id;
     }

     public int getId() {
        return this.id;
     }
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public Long getSalary() {
        return salary;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    public boolean isSalaryGreaterThan30k() {
        return this.salary > 30000;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return id == employee.id && Objects.equals(name, employee.name);
    }

    @Override
    public int hashCode() {
        return id;
    }

    public static void main(String[] args) {

        Person name1 = new Employee(1,"Haider");
        Person name2 = new Employee(2, "Haider");
        Person name3 = new Employee(2, "Millwala");

        Map<Person, Long> salaryMap = new HashMap<>();

        salaryMap.put(name1, 2000L);
        salaryMap.put(name2, 3000L);
        salaryMap.put(name3, 4000L);

        System.out.println(salaryMap.size());
        System.out.println(salaryMap.get(new Employee(2, "Haider")));

    }
}
