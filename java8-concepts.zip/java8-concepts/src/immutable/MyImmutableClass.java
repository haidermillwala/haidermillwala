package immutable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class MyImmutableClass {
    private final String id;
    private final String name;

    private final List<MutableClass> mutableClassList;
    MyImmutableClass(String id, String name, List<MutableClass> mutableClassList) {
        this.id = id;
        this.name=name;

        this.mutableClassList = new ArrayList<>();
        for(MutableClass mc: mutableClassList)
            this.mutableClassList.add(new MutableClass());
    }

    public List<MutableClass> getMutableClassList() {
        return Collections.unmodifiableList(this.mutableClassList);
    }
}
