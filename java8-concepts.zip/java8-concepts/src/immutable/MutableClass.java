package immutable;

public class MutableClass {
    private String value;

    public MutableClass() {}

    MutableClass(String value) {
        this.value = value;
    }

    public String getValue() { return value;}
}
