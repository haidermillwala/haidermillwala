import java.util.ArrayList;
import java.util.List;
public class PascalTriangle {

    public static void main(String[] args) {

        // Element at 5th row and 3rd column
        System.out.println(ncr(5-1, 3-1));
    }
    public static List<List<Integer>> generate(int rows) {

        List<List<Integer>> result = new ArrayList<>();

        for(int i=0; i<rows; i++) {

            for(int j=0; j<i; j++) {

            }
        }
        return null;
    }

    public static List<Integer> generateRow(int row) {

        List<Integer> result = new ArrayList<>();
        result.add(1);

        for(int col=1; col<row; col++) {
            int res = 1;
            res = res * row;
        }
        return null;
    }

    /*
        Formula to calculate element at rth row and cth column
    */
    public static int ncr(int row, int column) {

        int res = 1;

        for(int i=0; i<column; i++) {
            res = res * (row - i);
            res = res / (i + 1);
        }
        return res;
    }
}
