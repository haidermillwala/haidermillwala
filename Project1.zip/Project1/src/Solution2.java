import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Solution2 {

    public static void main(String[] args) {

        String str = "Haider,Millwala,Hello,World";

        List<String> split = Arrays.asList(str.split(","));

        Optional<String> result = split.stream().filter(name -> name.equals("Haider")).findFirst().map(string -> string + " Millwala");

        if(result.isPresent())
            System.out.println(result.get());
    }
}
