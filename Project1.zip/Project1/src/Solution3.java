import java.util.*;
import java.util.stream.Collectors;

class Employee {

    public String name;
    public String department;
    public Double salary;
    public Employee(String name, String department, Double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }
    public String getName() throws ArithmeticException {
        return name;
    }
    public String getDepartment() {
        return department;
    }
    public Double getSalary() {
        return salary;
    }
}

public class Solution3 {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
                new Employee("Haider", "IT", 1900d),
                new Employee("Husain", "Marketing", 2000d),
                new Employee("Afifa", "IT", 1500d),
                new Employee("Muneera", "IT", 1700d),
                new Employee("Naqiya", "Marketing", 1200d),
                new Employee("Murtaza", "Marketing", 1300d));

        Map<String, Employee> secondHighestSalariedEmployeeByDepartment = employees.stream().collect(
                Collectors.groupingBy(Employee::getDepartment,
                        Collectors.collectingAndThen(
                                Collectors.toCollection(ArrayList::new), list -> {
                                    Comparator.comparingDouble(Employee::getSalary).reversed();
                                    if(list.size() > 2)
                                        return list.get(1);
                                    else
                                        return null;
                                }
                        ))
        );


        Map<String, Double> secondHighestSalaryByDepartment = employees.stream().collect(
                Collectors.groupingBy(Employee::getDepartment,
                        Collectors.collectingAndThen(
                                Collectors.toCollection(ArrayList::new), list-> {
                                    Comparator.comparing(Employee::getSalary).reversed();
                                    if(list.size() > 2)
                                        return list.get(1).getSalary();
                                    else return null;
                                }
                        ))
        );

        Optional<Employee> secondHighestSalariesEmployee = employees.stream().sorted(
                Comparator.comparing(Employee::getSalary).reversed()).skip(1).findFirst();
    }
}