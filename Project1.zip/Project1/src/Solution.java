import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class Solution {

    static ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();

    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        String str = "google";

        Character result = ' ';
        for(Character c: str.toCharArray()) {

            if(str.indexOf(c) == str.lastIndexOf(c)) {
                result = c;
                break;
            }

        }
        System.out.println(result);

        Thread1 t1 = new Thread1();
        t1.start();

        Thread2 t2= new Thread2();
        t2.start();

        Class c = Class.forName("Solution$Thread2");
        Method[] method = c.getDeclaredMethods();

        Method m = c.getDeclaredMethod("printName", String.class);
        m.invoke(t2, "Hello");

    }

    public static class Thread1 extends Thread {

        @Override
        public void run() {
            map.put("Hello", "World");
            map.put("Hello1", "World");
            map.put("Hello2", "World");
            map.put("Hello3", "World");
            map.put("Hello4", "World");
            map.put("Hello5", "World");
        }
    }

    public static class Thread2 extends Thread {

        @Override
        public void run() {
            System.out.println(map.size());
            System.out.println(map.get("Hello"));
        }

        private void printName(String name) {
            System.out.println(name);
        }
    }


}





