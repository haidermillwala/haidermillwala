import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

class A {
    A() {
        System.out.print("A");
    }

    A(int i) {
        this();
        System.out.print(i);
    }
}

class B extends A {

    B() {
        System.out.print("B");
    }

    B(int i) {
        this();
        System.out.print(i + 3);
    }
}

public class WordList {

    public static void main(String[] args) {

        new B(5);

        List<String> input = Arrays.asList("desserts", "diapers", "praised", "stressed", "stressed");

        //System.out.println(maxEqualSubset(input));
    }

    public static Long maxEqualSubset(List<String> words) {
        Long result = Long.MIN_VALUE;

        Map<String, Long> sortedMap = words.stream().collect(Collectors.groupingBy(word -> {
            char[] ch = word.toCharArray();
            Arrays.sort(ch);
            return new String(ch);
        }, Collectors.counting()));

        for(Map.Entry<String, Long> entry: sortedMap.entrySet()) {
            if(entry.getValue() > result)
                result = entry.getValue();
        }
        return result;

    }
}
